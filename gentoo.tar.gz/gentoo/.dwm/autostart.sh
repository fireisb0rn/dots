#!/bin/bash

slstatus &
clipnotify &
clipmenud &
pkill slstatus
slstatus &
xrdb merge ~/.Xresources && xdotool key super+F5 && kill -USR1 $(pidof st)
#feh --bg-scale ~/Pictures/Wallpapers/1.jpeg
