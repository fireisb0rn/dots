-- require("lazy").setup({
--   { 'rose-pine/neovim', name = 'rose-pine' }
-- })
return{ 
	"rose-pine/neovim", 
	priority = 1000 , 
  lazy = false,
	config = function()
		vim.cmd('colorscheme rose-pine')
	end, 
	opts = { 
		defaults = {
			lazy = 	false,
		}
	}
}
