return{ 
	"shaunsingh/moonlight.nvim", 
	priority = 1000 , 
  -- lazy = false,
	-- config = function()
	-- 	vim.cmd('colorscheme gruvbox')
	-- end, 
	opts = { 
		defaults = {
			-- lazy = 	false,
		}
	}
}

