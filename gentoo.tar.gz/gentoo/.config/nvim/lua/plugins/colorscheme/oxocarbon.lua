return{ 
	"nyoom-engineering/oxocarbon.nvim", 
	priority = 1000 , 
  lazy = false,
	config = function()
		vim.cmd('colorscheme oxocarbon')
	end, 
	opts = { 
		defaults = {
			lazy = 	false,
		}
	}
}

