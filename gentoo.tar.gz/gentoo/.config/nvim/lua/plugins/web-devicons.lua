return {
  'nvim-tree/nvim-web-devicons',
	lazy = false,
}
