return {
  "folke/which-key.nvim",
	lazy = false,
}
