local config = function()
  require('dashboard').setup({
    theme = 'hyper', --  theme is doom and hyper default is hyper
    config = {
      -- week_header = {
      --   enable = true,
      -- },
    header = {
        
"                                                   ",
" ███▄    █ ▓█████  ▒█████   ██▒   █▓ ██▓ ███▄ ▄███▓",
" ██ ▀█   █ ▓█   ▀ ▒██▒  ██▒▓██░   █▒▓██▒▓██▒▀█▀ ██▒",
"▓██  ▀█ ██▒▒███   ▒██░  ██▒ ▓██  █▒░▒██▒▓██    ▓██░",
"▓██▒  ▐▌██▒▒▓█  ▄ ▒██   ██░  ▒██ █░░░██░▒██    ▒██ ",
"▒██░   ▓██░░▒████▒░ ████▓▒░   ▒▀█░  ░██░▒██▒   ░██▒",
"░ ▒░   ▒ ▒ ░░ ▒░ ░░ ▒░▒░▒░    ░ ▐░  ░▓  ░ ▒░   ░  ░",
"░ ░░   ░ ▒░ ░ ░  ░  ░ ▒ ▒░    ░ ░░   ▒ ░░  ░      ░",
"   ░   ░ ░    ░   ░ ░ ░ ▒       ░░   ▒ ░░      ░   ",
"         ░    ░  ░    ░ ░        ░   ░         ░   ",
"                                ░                  ",
"                                                   ",
      },
    shortcut = {
        { 
          desc = '󰊳 Update', 
          group = '@property', 
          action = 'Lazy update', 
          key = 'u' 
        },
        {
          desc = '󰒲 Lazy', 
          group = '@variable', 
          action = 'Lazy', 
          key = 'l' 
        },
        {
          icon_hl = '@variable',
          desc = ' Files',
          group = 'Label',
          action = 'Telescope find_files',
          key = 'f',
        }, 
        {
          icon_hl = '@variable',
          desc = ' Telescope',
          group = 'Diagnostics',
          action = 'Telescope',
          key = 't',
        }, 
        {
          desc = '󰩈 Exit',
          group = 'Exit',
          action = 'q',
          key = 'q',
        },
      },
    project = { enable = false, limit = 8, icon = 'your icon', label = '', action = 'Telescope find_files cwd=' },
    footer = {},
    },
  })
end 

return {
    "nvimdev/dashboard-nvim",
    event = 'VimEnter',
	  config = config,
    dependencies = {{ 'nvim-tree/nvim-web-devicons' }} 
}
