local keymap = vim.keymap
--Comments
vim.api.nvim_set_keymap("n", "<C-_", "gcc", { noremap = true})
vim.api.nvim_set_keymap("v", "<C-_", "gcc", { noremap = true})

-- Indenting
keymap.set("v", "<", "<gv" )
keymap.set("v", ">", ">gv" )

--telescope
keymap.set("n", "<leader>tb", ":Telescope buffers<CR>", { noremap = true, silent = true})
keymap.set("n", "<leader>tf", ":Telescope find_files<CR>", { noremap = true, silent = true})
keymap.set("n", "<leader>ts", ":Telescope<CR>", { noremap = true, silent = true})

--nvimtree
keymap.set("n", "<leader>nm", ":NvimTreeFocus<CR>", { noremap = true, silent = true})
keymap.set("n", "<leader>nf", ":NvimTreeToggle<CR>", { noremap = true, silent = true})
