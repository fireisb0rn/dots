local opt = vim.opt
--tab
opt.tabstop = 2
opt.shiftwidth = 2
opt.softtabstop = 2
opt.expandtab = true
opt.smartindent = true
opt.wrap = false

--search
opt.incsearch = true
opt.ignorecase = true
opt.smartcase = true
opt.hlsearch = false

--apperance
opt.number = true
opt.relativenumber = true
opt.termguicolors = true
opt.background = "dark"
opt.cursorline = true
-- opt.pumheight = 10
-- opt.cmdheight = 1
-- opt.scrolloff = 10
--opt.complete = "menuone,noinsert,noselect"
--opt.colorcolumn = '100'
--opt.signcolumn = "yes"
--opt.showtabline = 3

--behaviour
-- opt.hidden = true
-- opt.backspace = "indent,eol,start"
-- opt.autochdir = false
opt.clipboard:append("unnamedplus")


