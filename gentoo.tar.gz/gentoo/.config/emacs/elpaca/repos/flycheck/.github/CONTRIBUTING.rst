===========
 Thank you
===========

Thank you very much for your interest in contributing to Flycheck! We’d like to
warmly welcome you in the Flycheck community, and hope that you enjoy your time
with us!

Flycheck’s documentation provides a comprehensive Contributor Guide which shows
how you can contribute to Flycheck and helps you through all stages of the
contribution process.

Please read it at
<http://www.flycheck.org/en/latest/contributor/contributing.html>.
