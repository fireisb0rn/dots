sudo-edit
=========

Utilities for opening files with sudo
