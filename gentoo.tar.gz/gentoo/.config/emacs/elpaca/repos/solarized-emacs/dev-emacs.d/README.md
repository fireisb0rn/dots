# minimal init

Just a minimal init to test the theme without touching any user init.


```sh
./dev-emacs.d/start.sh
```
