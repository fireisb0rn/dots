#!/bin/bash

slstatus &
#./.fehbg &
feh --bg-scale ~/Pictures/Wallpapers/aa1.png
