#!/bin/bash

sudo apt install build-essential libx11-dev libxinerama-dev libfreetype6-dev libfontconfig1-dev libxinerama-dev libfontconfig1-devcd
sudo apt install -y xorg xbindkeys xinput intel-microcode libpam0g-dev libxcb-xkb-dev
sudo apt install -y dialog dosfstools avahi-daemon acpi acpid gvfs-backends pcmanfm pulseaudio alsa-utils pavucontrol network-manager firefox-esr feh fonts-firacode papirus-icon-theme numlockx dunst libnotify-bin unzip scrot neovim zathura mpv cmus nala xarchiver nala rar zip 

xdg-user-dirs-update

sudo systemctl enable avahi-daemon
sudo systemctl enable acpid

git clone --recurse-submodules https://github.com/fairyglade/ly

cd ly

sudo make

make run 

sudo make install installsystemd

sudo systemctl enable ly.service

cd ~/dots/.config/suckless/dwm

make && sudo make install

cd ~/dots/.config/suckless/dmenu

make && sudo make install

cd ~/dots/.config/suckless/st

make && sudo make install

cd ~/dots/.config/suckless/slstatus

make && sudo make install

sudo cp -r ~/dots/.config ~/

sudo cp -r ~/dots/.bin ~/

sudo cp -r ~/dots/.dwm ~/

sudo cp -r ~/dots/.bashrc ~/

mkdir ~/Pictures/Wallpapers

sudo cp -r ~/dots/aa1.png ~/Pictures/Wallpapers
